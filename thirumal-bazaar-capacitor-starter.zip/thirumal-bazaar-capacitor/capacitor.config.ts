import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.thirumalbazaar.app',
  appName: 'Thirumal Bazaar',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
